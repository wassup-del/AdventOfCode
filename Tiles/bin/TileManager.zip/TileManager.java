//INgrid Yan
//Adv Programmin P1
//Jackson
//this program creates a list of tiles and can add tiles
//draw tiles, raise tiles, lower tiles
//delte tiles, delete tiles in a certain space,
//and shuffle the tiles

import java.util.ArrayList;
import java.util.Collections;
import java.awt.*;

 
public class TileManager {
	private ArrayList<Tile> TileList;
	
	//constructor	
	public TileManager() {
		TileList = new ArrayList<Tile>();	
	}
	
	//adds a tile to the list
	public void addTile(Tile rect) {
		TileList.add(rect);
	}
	
	//draws all the tiles from beginning of list to end
	public void drawAll(Graphics g) {
		for(int i = 0; i < TileList.size(); i++) {
			TileList.get(i).draw(g);
		}
	}
	
	//changes the color of the topmost tile
	//input: x y coordinates
	//output: none
	public void ChangeColor(int x, int y)
	{
		for(int i = TileList.size()-1; i >= 0; i--) {
			Tile currentTile = TileList.get(i);

			//if clicked move tile to the top
			if (TileContainsPoint(currentTile, x, y) == true) {
				currentTile.ChangeColor();
				return;
			}
		}	
	}

	//helper method that returns x, 
	//y coordinates of top left 
	//and bottom right point of rectangle
	//coordinates[0,1,2,3]
	//x1, x2, y1, y2
	//input: Tile
	//output: array with 4 coordinates of tile
	private int[] getCoordinates(Tile t) {
		int[] coordinates = new int[4];
		
		coordinates[0] = t.getX();
		coordinates[1] = coordinates[0] + t.getWidth();
		coordinates[2] = t.getY();
		coordinates[3] = coordinates[2] + t.getHeight();
		return coordinates;
	}
	
	//Check to see if the points, x,y 
	//is inside the tile;
	//input: coordinates x and y, and the Tile
	//output: true if x and y points are in tile
	//false if not
	private boolean TileContainsPoint( Tile t, int x, int y) {
		int[] coordinates = new int[4];
		coordinates = getCoordinates(t);
		
		if ( (x > coordinates[0]) && (x < coordinates[1]) &&
			 (y > coordinates[2]) && (y < coordinates[3])) {
			return true;
		} else {
			return false;
		}
	}
	//if tile is left clicked, 
	//move the topmost tile to the top of list.
	//input: x and y coordinates
	//output: none
	public void raise(int x, int y) {
		//go to each tile in the list
		for(int i = TileList.size()-1; i >= 0; i--) {
			Tile currentTile = TileList.get(i);
			//if clicked move tile to the top
			if (TileContainsPoint(currentTile, x, y) == true) {
				TileList.remove(i);
				TileList.add(TileList.size(), currentTile);
				return;
			}
		}	
	}

	//shift left clicks,
	//move topmost tile to bottow of list
	//input: x and y coordinates
	//output: none
	public void lower(int x, int y) {
		//go to each tile in the list
		for(int i = TileList.size()-1; i >= 0; i--) {
			Tile currentTile = TileList.get(i);
			//check to see if its clicked
			if (TileContainsPoint(currentTile, x, y) == true) {
				TileList.remove(i);
				TileList.add(0, currentTile);
				return;
			}
		}
	}
	
	//right clicks,
	//if coordinates touch any tiles, 
	//delete topmost of tile from list
	//input: x and y coordinates
	//output: none
	public void delete(int x, int y) {
		//go to each tile in the list
		for(int i = TileList.size()-1; i >= 0; i--) {
			Tile currentTile = TileList.get(i);
			if (TileContainsPoint(currentTile, x, y) == true) {
				//if clicked
				TileList.remove(i);
				return;
			}
		}		
	}
	
	//rights shift clicks,
	//if coordinates touch any tiles, 
	//delete all tiles from list
	//input: x and y coordinates
	//output: none
	public void deleteAll(int x, int y) {
		//go to each tile in the list
		for(int i = TileList.size() - 1; i >= 0; i--) {
			Tile currentTile = TileList.get(i);
			
			if (TileContainsPoint(currentTile, x, y) == true) {
				//if clicked
				TileList.remove(i);
			}
		}			
	}

	//press s,
	//every tile moves to a random position.
	//input: width and height of the screen
	//output: none
	//exception: if x/y limit is equal to or 
	//smaller than 0, throw IllegalArgumentException.
	public void shuffle(int width, int height) {
		//go to each tile in the list

		for(int i = TileList.size()-1; i >= 0; i--) {
			Tile currentTile = TileList.get(i);
			int xlimit = width - currentTile.getWidth(); //x
			int ylimit = height - currentTile.getHeight();//y
			
			//checks to see if x/y limit is too small.
			if (xlimit <= 0 || ylimit <= 0) {
				throw new IllegalArgumentException("Width and/or height is too small!");
			}
			
			//move the rectangle somewhere random on the screen
			int randomX = (int) (Math.random() * (xlimit));
			int randomY = (int) (Math.random() * (ylimit));			
			currentTile.setX(randomX);
			currentTile.setY(randomY);
			
			//shuffle the spot of the tile in the list
			Collections.shuffle(TileList);
			
		}	
	}
	
}
